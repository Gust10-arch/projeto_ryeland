import { useEffect, useRef, useState, type FormEvent } from "react"

type IconName = "grid" | "sheep" | "dna" | "truck" | "calendar" | "users" | "book" | "chevron" | "arrow" | "plus" | "search" | "bell" | "pin" | "sun" | "leaf" | "close" | "check" | "download" | "help" | "menu" | "logout" | "clock" | "weight"
function Icon({
  name,
  size = 20,
  className = "",
}: {
  name: IconName
  size?: number
  className?: string
}) {
  const paths: Record<IconName, React.ReactNode> = {
    grid: (
      <>
        <rect x="3" y="3" width="7" height="7" rx="1.4" />
        <rect x="14" y="3" width="7" height="7" rx="1.4" />
        <rect x="3" y="14" width="7" height="7" rx="1.4" />
        <rect x="14" y="14" width="7" height="7" rx="1.4" />
      </>
    ),
    sheep: (
      <>
        <path d="M6 17v4m10-4v4M5 9a3 3 0 0 1 4-4 3 3 0 0 1 5 0 3 3 0 0 1 4 4v5c0 3-3 4-7 4s-7-2-7-5a3 3 0 0 1 1-4Z" />
        <path d="m17 8 4-1 1 3-2 4h-3m3-4h.01" />
      </>
    ),
    dna: (
      <>
        <path d="M6 3c0 9 12 9 12 18M18 3c0 9-12 9-12 18M7 5h10M8 8h8M8 16h8M7 19h10" />
      </>
    ),
    truck: (
      <>
        <path d="M3 5h11v12H3zM14 9h4l3 4v4h-7" />
        <circle cx="7" cy="18" r="2" />
        <circle cx="18" cy="18" r="2" />
      </>
    ),
    calendar: (
      <>
        <rect x="3" y="5" width="18" height="16" rx="2" />
        <path d="M7 3v4m10-4v4M3 11h18m-12 4h.01m4 0h.01m4 0h.01m-8 4h.01m4 0h.01" />
      </>
    ),
    users: (
      <>
        <circle cx="9" cy="7" r="3" />
        <path d="M3 21v-3a6 6 0 0 1 12 0v3M16 4a3 3 0 0 1 0 6m2 5a4 4 0 0 1 3 4v2" />
      </>
    ),
    book: (
      <>
        <path d="M12 5c-3-2-6-2-9-1v15c3-1 6-1 9 1 3-2 6-2 9-1V4c-3-1-6-1-9 1Zm0 0v15" />
      </>
    ),
    chevron: <path d="m9 5 7 7-7 7" />,
    arrow: <path d="M4 12h16m-6-6 6 6-6 6" />,
    plus: <path d="M12 5v14M5 12h14" />,
    search: (
      <>
        <circle cx="10.5" cy="10.5" r="6.5" />
        <path d="m16 16 5 5" />
      </>
    ),
    bell: (
      <>
        <path d="M5 17h14l-2-4V9a5 5 0 0 0-10 0v4l-2 4ZM10 21h4" />
      </>
    ),
    pin: (
      <>
        <path d="M19 10c0 5-7 11-7 11S5 15 5 10a7 7 0 0 1 14 0Z" />
        <circle cx="12" cy="10" r="2.5" />
      </>
    ),
    sun: (
      <>
        <circle cx="12" cy="12" r="4" />
        <path d="M12 2v2m0 16v2M2 12h2m16 0h2M5 5l1 1m12 12 1 1M5 19l1-1M18 6l1-1" />
      </>
    ),
    leaf: (
      <>
        <path d="M20 3C8 2 2 7 5 15c8 5 15-1 15-12ZM4 21 16 9" />
      </>
    ),
    close: <path d="m6 6 12 12M6 18 18 6" />,
    check: <path d="m5 12 4 4L19 6" />,
    download: <path d="M12 3v12m-5-5 5 5 5-5M4 16v5h16v-5" />,
    help: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M9 9a3 3 0 0 1 6 0c0 2-3 2-3 5m0 3h.01" />
      </>
    ),
    menu: <path d="M4 6h16M4 12h16M4 18h16" />,
    logout: <path d="M10 4H4v16h6m4-14 6 6-6 6M8 12h12" />,
    clock: (
      <>
        <circle cx="12" cy="12" r="9" />
        <path d="M12 7v5l3 2" />
      </>
    ),
    weight: (
      <>
        <path d="m6 8-3 13h18L18 8H6Z" />
        <circle cx="12" cy="5" r="3" />
      </>
    ),
  }
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.65"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
      aria-hidden="true"
    >
      {paths[name]}
    </svg>
  )
}

type Animal = {
  id: string
  name: string
  breed: string
  species: string
  sex: string
  age: string
  weight: number
  status: string
  color: string
}
const initialAnimals: Animal[] = [
  {
    id: "OV-001",
    name: "Aurora",
    breed: "Santa Inês",
    species: "Ovino",
    sex: "Fêmea",
    age: "18 meses",
    weight: 48.5,
    status: "Reprodução",
    color: "purple",
  },
  {
    id: "CP-012",
    name: "Valente",
    breed: "Boer",
    species: "Caprino",
    sex: "Macho",
    age: "24 meses",
    weight: 72.3,
    status: "Seleção genética",
    color: "green",
  },
  {
    id: "OV-023",
    name: "Estrela",
    breed: "Dorper",
    species: "Ovino",
    sex: "Fêmea",
    age: "12 meses",
    weight: 42.8,
    status: "Engorda",
    color: "orange",
  },
  {
    id: "CP-008",
    name: "Sertão",
    breed: "Anglo-Nubiana",
    species: "Caprino",
    sex: "Macho",
    age: "20 meses",
    weight: 65.0,
    status: "Seleção genética",
    color: "green",
  },
]
const navigation: {
  label: string
  icon: IconName
  count?: string
}[] = [
  { label: "Visão geral", icon: "grid" },
  { label: "Meu rebanho", icon: "sheep" },
  { label: "Seleção genética", icon: "dna" },
  { label: "Logística", icon: "truck" },
  { label: "Agenda", icon: "calendar", count: "4" },
  { label: "Clientes", icon: "users" },
]
const initialTasks = [
  {
    title: "Vacinação do lote 03",
    description: "18 animais · Manejo sanitário",
    time: "08:00",
    color: "orange",
    done: false,
  },
  {
    title: "Pesagem dos cordeiros",
    description: "Lote 01 · Acompanhamento de peso",
    time: "10:30",
    color: "green",
    done: false,
  },
  {
    title: "Visita de comprador",
    description: "Carlos Oliveira · Seleção genética",
    time: "14:00",
    color: "purple",
    done: false,
  },
]
function Modal({
  title,
  onClose,
  children,
}: {
  title: string
  onClose: () => void
  children: React.ReactNode
}) {
  const ref = useRef<HTMLDialogElement>(null)
  useEffect(() => {
    ref.current?.showModal()
  }, [])
  return (
    <dialog
      ref={ref}
      className="modal"
      aria-label={title}
      onCancel={onClose}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose()
      }}
    >
      <div className="modal-head">
        <h2>{title}</h2>
        <button className="icon-button" aria-label="Fechar" onClick={onClose}>
          <Icon name="close" />
        </button>
      </div>
      {children}
    </dialog>
  )
}
function Badge({
  color,
  children,
}: {
  color: string
  children: React.ReactNode
}) {
  return (
    <span className={`badge ${color}`}>
      <span className="badge-dot" />
      {children}
    </span>
  )
}

export default function App() {
  const [page, setPage] = useState("Visão geral")
  const [animals, setAnimals] = useState<Animal[]>(() => {
    try {
      return (
        JSON.parse(localStorage.getItem("ryeland-animals") || "null") ||
        initialAnimals
      )
    } catch {
      return initialAnimals
    }
  })
  const [query, setQuery] = useState("")
  const [filter, setFilter] = useState("Todos os animais")
  const [modal, setModal] =
    useState<"animal" | "notifications" | "help" | "profile" | null>(null)
  const [selected, setSelected] = useState<Animal | null>(null)
  const [tasks, setTasks] = useState(initialTasks)
  const [toast, setToast] = useState("")
  const [mobileNav, setMobileNav] = useState(false)
  const [period, setPeriod] = useState("Este mês")
  const [agendaDate, setAgendaDate] = useState("18")
  useEffect(() => {
    document.title = "Ryeland | Gestão do campo"
    document.documentElement.lang = "pt-BR"
  }, [])
  useEffect(() => {
    localStorage.setItem("ryeland-animals", JSON.stringify(animals))
  }, [animals])
  useEffect(() => {
    if (!toast) return
    const timer = setTimeout(() => setToast(""), 4000)
    return () => clearTimeout(timer)
  }, [toast])
  const go = (target: string) => {
    setPage(target)
    setQuery("")
    setMobileNav(false)
  }
  const shown = animals.filter(
    (a) =>
      (filter === "Todos os animais" ||
        a.species === (filter === "Ovinos" ? "Ovino" : "Caprino")) &&
      `${a.name} ${a.id} ${a.breed}`
        .toLowerCase()
        .includes(query.toLowerCase()),
  )
  function addAnimal(e: FormEvent<HTMLFormElement>) {
    e.preventDefault()
    const data = new FormData(e.currentTarget)
    const species = String(data.get("species"))
    const status = String(data.get("status"))
    setAnimals([
      ...animals,
      {
        id: `${
          species === "Ovino" ? "OV" : "CP"
        }-${String(Date.now()).slice(-5)}`,
        name: String(data.get("name")),
        breed: String(data.get("breed")),
        species,
        sex: String(data.get("sex")),
        age: `${data.get("age")} meses`,
        weight: Number(data.get("weight")),
        status,
        color:
          status === "Engorda"
            ? "orange"
            : status === "Reprodução"
              ? "purple"
              : "green",
      },
    ])
    setModal(null)
    setToast("Animal cadastrado com sucesso.")
  }
  function exportReport() {
    const rows = [
      [
        "Identificação",
        "Nome",
        "Espécie",
        "Raça",
        "Sexo",
        "Idade",
        "Peso (kg)",
        "Status",
      ],
      ...animals.map((a) => [
        a.id,
        a.name,
        a.species,
        a.breed,
        a.sex,
        a.age,
        String(a.weight),
        a.status,
      ]),
    ]
    const url = URL.createObjectURL(
      new Blob(["\uFEFF" + rows.map((row) => row.join(";")).join("\n")], {
        type: "text/csv;charset=utf-8",
      }),
    )
    const link = document.createElement("a")
    link.href = url
    link.download = "ryeland-rebanho.csv"
    link.click()
    URL.revokeObjectURL(url)
    setToast("Relatório do rebanho exportado.")
  }
  const renderAnimalTable = ({ compact = false }: {
    compact?: boolean
  } = {}) => (
    <section className="panel herd-panel">
      <div className="panel-heading">
        <div>
          <h2>{compact ? "Seu rebanho, de perto" : "Animais cadastrados"}</h2>
          <p>
            {compact
              ? "Acompanhe os animais e suas fases de produção."
              : `${shown.length} animais no cadastro demonstrativo`}
          </p>
        </div>
        {compact ? (
          <button className="text-button" onClick={() => go("Meu rebanho")}>
            Ver rebanho <Icon name="arrow" size={16} />
          </button>
        ) : (
          <button className="secondary small" onClick={exportReport}>
            <Icon name="download" size={16} /> Exportar
          </button>
        )}
      </div>
      <div className="table-tools">
        <div className="segmented">
          {["Todos os animais", "Ovinos", "Caprinos"].map((f) => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={filter === f ? "selected" : ""}
            >
              {f}
            </button>
          ))}
        </div>
        <div className="table-search">
          <Icon name="search" size={16} />
          <input
            aria-label="Buscar animal"
            placeholder="Buscar animal..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>
      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              <th>Animal</th>
              <th>Raça / Espécie</th>
              <th>Idade</th>
              <th>Peso</th>
              <th>Status</th>
              <th>
                <span className="sr-only">Detalhes</span>
              </th>
            </tr>
          </thead>
          <tbody>
            {(compact ? shown.slice(0, 4) : shown).map((a) => (
              <tr key={a.id} onClick={() => setSelected(a)}>
                <td>
                  <div className="animal-cell">
                    <div
                      className={`animal-avatar ${
                        a.species === "Caprino" ? "tan" : ""
                      }`}
                    >
                      <Icon name="sheep" size={22} />
                    </div>
                    <div>
                      <strong>{a.name}</strong>
                      <small>
                        {a.id} <span>· {a.sex}</span>
                      </small>
                    </div>
                  </div>
                </td>
                <td>
                  <strong className="breed-name">{a.breed}</strong>
                  <small>{a.species}</small>
                </td>
                <td>{a.age}</td>
                <td>
                  {a.weight.toLocaleString("pt-BR", {
                    minimumFractionDigits: 1,
                  })}{" "}
                  <span className="muted">kg</span>
                </td>
                <td>
                  <Badge color={a.color}>{a.status}</Badge>
                </td>
                <td>
                  <button
                    aria-label={`Ver detalhes de ${a.name}`}
                    className="icon-button"
                    onClick={(e) => {
                      e.stopPropagation()
                      setSelected(a)
                    }}
                  >
                    <Icon name="chevron" size={16} />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        {shown.length === 0 && (
          <div className="empty-state">
            Nenhum animal encontrado. Tente outro nome ou filtro.
          </div>
        )}
      </div>
      {compact && (
        <div className="table-footer">
          <span>Mostrando {Math.min(shown.length, 4)} animais do cadastro</span>
          <span className="live-dot">Dados demonstrativos</span>
        </div>
      )}
    </section>
  )
  const Agenda = () => (
    <section className="panel agenda-panel">
      <div className="panel-heading">
        <div>
          <h2>Agenda de hoje</h2>
          <p>Quarta-feira, 18 de junho</p>
        </div>
        <button
          className="icon-button"
          aria-label="Ver agenda completa"
          onClick={() => go("Agenda")}
        >
          <Icon name="calendar" size={19} />
        </button>
      </div>
      <div className="task-list">
        {tasks.map((task, index) => (
          <div
            className={`task ${task.done ? "task-done" : ""}`}
            key={task.title}
          >
            <button
              className={`task-check ${task.color} ${
                task.done ? "checked" : ""
              }`}
              aria-label={`${task.done ? "Reabrir" : "Concluir"} ${task.title}`}
              onClick={() =>
                setTasks(
                  tasks.map((t, i) =>
                    i === index ? { ...t, done: !t.done } : t,
                  ),
                )
              }
            >
              {task.done ? <Icon name="check" size={12} /> : <span />}
            </button>
            <div>
              <span className="task-time">{task.time}</span>
              <h3>{task.title}</h3>
              <p>{task.description}</p>
            </div>
          </div>
        ))}
      </div>
      <button className="agenda-link" onClick={() => go("Agenda")}>
        Ver agenda completa <Icon name="arrow" size={16} />
      </button>
    </section>
  )

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileNav ? "is-open" : ""}`}>
        <button
          className="brand"
          onClick={() => go("Visão geral")}
          aria-label="Ryeland, início"
        >
          <div className="brand-symbol">
            <Icon name="sheep" size={30} />
          </div>
          <span>
            ryeland<span className="brand-period">.</span>
            <small>CUIDAR. CRESCER. CONECTAR.</small>
          </span>
        </button>
        <div className="farm-switch">
          <div className="farm-icon">
            <Icon name="leaf" size={19} />
          </div>
          <div>
            <strong>Fazenda Boa Esperança</strong>
            <span>
              <Icon name="pin" size={11} /> Tauá, Ceará
            </span>
          </div>
          <Icon name="chevron" size={14} />
        </div>
        <div className="nav-label">GESTÃO DA PROPRIEDADE</div>
        <nav>
          {navigation.map((item) => (
            <button
              key={item.label}
              className={`nav-item ${page === item.label ? "active" : ""}`}
              onClick={() => go(item.label)}
            >
              <Icon name={item.icon} />
              <span>{item.label}</span>
              {item.count && <span className="nav-count">{item.count}</span>}
              {page === item.label && <span className="nav-active-dot" />}
            </button>
          ))}
        </nav>
        <div className="nav-divider" />
        <div className="nav-label">PROJETO RYELAND</div>
        <button
          className={`nav-item ${page === "Sobre o projeto" ? "active" : ""}`}
          onClick={() => go("Sobre o projeto")}
        >
          <Icon name="book" />
          <span>Sobre o projeto</span>
          <span className="new-label">NOVO</span>
        </button>
        <div className="sidebar-bottom">
          <div className="help-card">
            <div className="help-title">
              <Icon name="help" size={19} />
              <strong>Vamos crescer juntos?</strong>
            </div>
            <p>O cuidado com o campo começa com uma boa conversa.</p>
            <button onClick={() => setModal("help")}>
              Conheça o Ryeland <Icon name="arrow" size={15} />
            </button>
          </div>
          <button className="profile" onClick={() => setModal("profile")}>
            <div className="avatar">FG</div>
            <div>
              <strong>Francisco Gustavo</strong>
              <span>Administrador</span>
            </div>
            <Icon name="chevron" size={16} />
          </button>
        </div>
      </aside>
      {mobileNav && (
        <button
          className="mobile-overlay"
          aria-label="Fechar menu"
          onClick={() => setMobileNav(false)}
        />
      )}
      <div className="main-shell">
        <header className="topbar">
          <div className="breadcrumb">
            <button
              className="mobile-menu icon-button"
              aria-label="Abrir menu"
              onClick={() => setMobileNav(true)}
            >
              <Icon name="menu" />
            </button>
            <span>Minha propriedade</span>
            <Icon name="chevron" size={13} />
            <strong>{page}</strong>
          </div>
          <div className="topbar-right">
            <div className="location">
              <Icon name="pin" size={15} /> Tauá, CE
            </div>
            <span className="top-divider" />
            <div className="weather">
              <Icon name="sun" size={20} /> 32° <span>Ensolarado</span>
            </div>
            <span className="top-divider" />
            <button
              className="notification-button icon-button"
              aria-label="Notificações"
              onClick={() => setModal("notifications")}
            >
              <Icon name="bell" />
              <span />
            </button>
            <button
              className="top-avatar"
              aria-label="Perfil"
              onClick={() => setModal("profile")}
            >
              FG
            </button>
          </div>
        </header>
        <main>
          <div className="page-heading">
            <div>
              <div className="eyebrow">DO CAMPO, PARA O FUTURO</div>
              <h1>
                {page === "Visão geral" ? "Bom dia, Francisco" : page}
                <span className="heading-dot">.</span>
              </h1>
              <p>
                {page === "Visão geral"
                  ? "Um novo dia para cuidar do seu rebanho e cultivar bons resultados."
                  : page === "Meu rebanho"
                    ? "Cada animal tem uma história. Acompanhe todas elas."
                    : page === "Seleção genética"
                      ? "Conheça o potencial do seu rebanho, geração após geração."
                      : page === "Logística"
                        ? "Do planejamento à entrega, mais segurança em cada trajeto."
                        : page === "Agenda"
                          ? "O cuidado certo, no momento certo."
                          : page === "Clientes"
                            ? "Boas relações também fazem o campo crescer."
                            : "Tecnologia que aproxima pessoas, animais e oportunidades."}
              </p>
            </div>
            <div className="heading-actions">
              {page === "Visão geral" && (
                <button className="secondary" onClick={() => go("Agenda")}>
                  <Icon name="calendar" size={16} /> 18 de junho, 2025
                </button>
              )}
              <button className="primary" onClick={() => setModal("animal")}>
                <Icon name="plus" size={18} /> Cadastrar animal
              </button>
            </div>
          </div>
          {page === "Visão geral" && (
            <>
              <section className="hero">
                <img
                  src={new URL("../assets/rebanho.jpg", import.meta.url).href}
                  alt="Rebanho de ovinos em pastagem, fotografia ilustrativa"
                />
                <div className="hero-shade" />
                <div className="hero-content">
                  <span className="hero-tag">
                    <span /> RAÍZES NO SERTÃO. OLHOS NO FUTURO.
                  </span>
                  <h2>
                    Seu rebanho bem cuidado.
                    <br />
                    Seu negócio mais forte.
                  </h2>
                  <p>
                    Da criação à comercialização, tudo conectado
                    <br className="desktop-break" /> em um só lugar. Feito para
                    quem vive do campo.
                  </p>
                  <button onClick={() => go("Meu rebanho")}>
                    Explorar meu rebanho <Icon name="arrow" size={17} />
                  </button>
                </div>
                <div className="hero-bottom">
                  <Icon name="pin" size={13} /> A força da ovinocaprinocultura
                  em Tauá, Ceará
                </div>
                <div className="hero-mark">
                  <Icon name="leaf" size={17} /> Crescendo com você
                </div>
              </section>
              <div className="section-caption">
                <h2>A propriedade em números</h2>
                <select
                  aria-label="Período dos indicadores"
                  value={period}
                  onChange={(e) => setPeriod(e.target.value)}
                >
                  <option>Este mês</option>
                  <option>Últimos 3 meses</option>
                  <option>Este ano</option>
                </select>
              </div>
              <div className="stats-grid">
                {[
                  {
                    label: "Total de animais",
                    value: String(248 + animals.length - initialAnimals.length),
                    icon: "sheep" as IconName,
                    color: "green",
                    change:
                      period === "Este mês"
                        ? "+12"
                        : period === "Este ano"
                          ? "+48"
                          : "+28",
                    detail: "animais no período",
                    sub: "156 ovinos",
                    sub2: "92 caprinos",
                  },
                  {
                    label: "Em seleção genética",
                    value: "32",
                    icon: "dna" as IconName,
                    color: "purple",
                    change: "+4",
                    detail: "em relação ao mês anterior",
                    sub: "Potencial para leilões",
                  },
                  {
                    label: "Prontos para corte",
                    value: "64",
                    icon: "weight" as IconName,
                    color: "orange",
                    change: "+8",
                    detail: "em relação ao mês anterior",
                    sub: "Peso médio",
                    sub2: "42,5 kg",
                  },
                  {
                    label: "Transportes agendados",
                    value: "05",
                    icon: "truck" as IconName,
                    color: "blue",
                    change: "",
                    detail: "Próximo: 20 de junho",
                    sub: "3 entregas",
                    sub2: "2 retiradas",
                  },
                ].map((s) => (
                  <section className="stat-card" key={s.label}>
                    <div className="stat-top">
                      <span>{s.label}</span>
                      <div className={`stat-icon ${s.color}`}>
                        <Icon name={s.icon} size={21} />
                      </div>
                    </div>
                    <div className="stat-value">{s.value}</div>
                    <div className="stat-change">
                      {s.change && <strong>↗ {s.change}</strong>}
                      <span>{s.detail}</span>
                    </div>
                    <div className="stat-bottom">
                      <span>{s.sub}</span>
                      {s.sub2 && (
                        <>
                          <span className="tiny-dot" />
                          <span>{s.sub2}</span>
                        </>
                      )}
                    </div>
                  </section>
                ))}
              </div>
              <div className="dashboard-grid">
                {renderAnimalTable({ compact: true })}
                <div className="right-column">
                  <Agenda />
                  <section className="opportunity-card">
                    <div className="opportunity-icon">
                      <Icon name="dna" size={20} />
                    </div>
                    <span className="eyebrow">GENÉTICA QUE GERA VALOR</span>
                    <h3>
                      O próximo destaque
                      <br />
                      pode estar no seu rebanho.
                    </h3>
                    <p>
                      Acompanhe os animais com potencial para seleção e leilões.
                    </p>
                    <button onClick={() => go("Seleção genética")}>
                      Conhecer a seleção <Icon name="arrow" size={16} />
                    </button>
                    <div className="decor-circle" />
                  </section>
                </div>
              </div>
            </>
          )}
          {page === "Meu rebanho" && (
            <>
              <div className="info-strip">
                <Icon name="sheep" />
                <span>
                  Identificação individual, raça, peso e fase de produção em um
                  só lugar.
                </span>
                <Badge color="green">{animals.length} cadastrados</Badge>
              </div>
              {renderAnimalTable()}
            </>
          )}
          {page === "Seleção genética" && (
            <>
              <div className="info-strip">
                <Icon name="dna" />
                <span>
                  Avalie peso, linhagem e aptidão. A seleção final exige
                  avaliação técnica.
                </span>
              </div>
              <div className="genetics-grid">
                {animals
                  .filter((a) => a.status === "Seleção genética")
                  .map((a) => (
                    <section className="panel genetic-card" key={a.id}>
                      <div className="genetic-art">
                        <Icon name="sheep" size={64} />
                        <Badge color="green">Em avaliação</Badge>
                      </div>
                      <div className="genetic-content">
                        <span className="eyebrow">
                          {a.id} · {a.species}
                        </span>
                        <h2>{a.name}</h2>
                        <p>
                          {a.breed} · {a.sex} · {a.age}
                        </p>
                        <div className="genetic-info">
                          <span>
                            Peso atual<strong>{a.weight} kg</strong>
                          </span>
                          <span>
                            Finalidade<strong>Reprodução / Leilão</strong>
                          </span>
                        </div>
                        <p className="genetic-note">
                          Linhagem e avaliação zootécnica ainda não registradas.
                          Peso isolado não determina mérito genético.
                        </p>
                        <button
                          className="secondary"
                          onClick={() => setSelected(a)}
                        >
                          Ver ficha do animal <Icon name="arrow" size={16} />
                        </button>
                      </div>
                    </section>
                  ))}
              </div>
            </>
          )}
          {page === "Logística" && (
            <>
              <div className="info-strip">
                <Icon name="truck" />
                <span>
                  Antes do embarque: conferir GTA, condições sanitárias e
                  bem-estar dos animais.
                </span>
              </div>
              <section className="panel">
                <div className="panel-heading">
                  <div>
                    <h2>Próximas movimentações</h2>
                    <p>Planejamento demonstrativo de transporte</p>
                  </div>
                </div>
                {[
                  {
                    date: "20 JUN",
                    title: "Entrega de ovinos para corte",
                    route: "Fazenda Boa Esperança → Unidade de abate, Tauá",
                    amount: "24 ovinos",
                    status: "Confirmado",
                  },
                  {
                    date: "23 JUN",
                    title: "Transporte para leilão regional",
                    route: "Fazenda Boa Esperança → Parque de exposições, Tauá",
                    amount: "6 reprodutores",
                    status: "GTA pendente",
                  },
                  {
                    date: "26 JUN",
                    title: "Retirada de matrizes",
                    route: "Propriedade parceira, Independência → Tauá",
                    amount: "12 matrizes",
                    status: "Planejamento",
                  },
                ].map((item) => (
                  <div className="logistic-row" key={item.title}>
                    <div className="date-block">
                      {item.date.split(" ")[0]}
                      <small>{item.date.split(" ")[1]}</small>
                    </div>
                    <div>
                      <h3>{item.title}</h3>
                      <p>{item.route}</p>
                      <span>{item.amount}</span>
                    </div>
                    <Badge
                      color={item.status === "Confirmado" ? "green" : "orange"}
                    >
                      {item.status}
                    </Badge>
                  </div>
                ))}
              </section>
            </>
          )}
          {page === "Agenda" && (
            <div className="agenda-page">
              <section className="panel calendar-panel">
                <div className="panel-heading">
                  <div>
                    <h2>Junho de 2025</h2>
                    <p>Planeje o manejo e as visitas</p>
                  </div>
                  <Icon name="calendar" />
                </div>
                <div className="calendar-grid">
                  {["DOM", "SEG", "TER", "QUA", "QUI", "SEX", "SÁB"].map(
                    (d) => (
                      <span key={d}>{d}</span>
                    ),
                  )}
                  {Array.from({ length: 30 }, (_, i) => (
                    <button
                      key={i}
                      onClick={() => setAgendaDate(String(i + 1))}
                      className={`${
                        agendaDate === String(i + 1) ? "day-selected" : ""
                      } ${[18, 20, 23, 26].includes(i + 1) ? "has-event" : ""}`}
                    >
                      {i + 1}
                    </button>
                  ))}
                </div>
                <p className="calendar-caption">
                  <span className="badge-dot" /> Dias com atividades programadas
                </p>
              </section>
              <div>
                {agendaDate === "18" ? (
                  <Agenda />
                ) : (
                  <section className="panel selected-day">
                    <h2>{agendaDate} de junho</h2>
                    {["20", "23", "26"].includes(agendaDate) ? (
                      <>
                        <Badge color="green">Transporte programado</Badge>
                        <p>
                          Consulte a movimentação e os cuidados de embarque na
                          logística.
                        </p>
                        <button
                          className="primary"
                          onClick={() => go("Logística")}
                        >
                          Ver logística <Icon name="arrow" size={16} />
                        </button>
                      </>
                    ) : (
                      <p>Nenhuma atividade programada para este dia.</p>
                    )}
                  </section>
                )}
              </div>
            </div>
          )}
          {page === "Clientes" && (
            <section className="panel">
              <div className="panel-heading">
                <div>
                  <h2>Conexões do campo</h2>
                  <p>Compradores e parceiros · dados demonstrativos</p>
                </div>
              </div>
              {[
                {
                  name: "Carlos Oliveira",
                  initials: "CO",
                  type: "Comprador de reprodutores",
                  city: "Tauá, CE",
                  next: "Visita · 18 de junho, 14h",
                },
                {
                  name: "Cooperativa Sertão Vivo",
                  initials: "SV",
                  type: "Parceiro comercial · Produção de carne",
                  city: "Tauá, CE",
                  next: "Entrega · 20 de junho",
                },
                {
                  name: "Maria Fernandes",
                  initials: "MF",
                  type: "Criadora · Seleção de matrizes",
                  city: "Independência, CE",
                  next: "Retirada · 26 de junho",
                },
              ].map((c) => (
                <div className="client-row" key={c.name}>
                  <div className="client-avatar">{c.initials}</div>
                  <div>
                    <h3>{c.name}</h3>
                    <p>{c.type}</p>
                    <small>{c.city}</small>
                  </div>
                  <span>
                    <Icon name="calendar" size={16} />
                    {c.next}
                  </span>
                </div>
              ))}
            </section>
          )}
          {page === "Sobre o projeto" && (
            <section className="panel project-page">
              <span className="eyebrow">IFCE · CAMPUS ARACATI</span>
              <h2>Do sertão à tecnologia.</h2>
              <p className="project-intro">
                O Ryeland é uma proposta de gestão da ovinocaprinocultura com
                foco em Tauá, Ceará, unindo manejo, produção de carne, seleção
                genética, logística e relacionamento com compradores.
              </p>
              <div className="project-columns">
                <div>
                  <h3>Decisões conscientes de leiaute</h3>
                  <p>
                    <strong>O rebanho no centro.</strong> A identificação
                    individual, raça, sexo, idade e peso ajudam a acompanhar o
                    animal ao longo das fases de produção. Separar ovinos e
                    caprinos evita tratar espécies com necessidades diferentes
                    como uma só.
                  </p>
                  <p>
                    <strong>Genética não é só aparência.</strong> A tela
                    distingue candidatos em avaliação de animais comprovados.
                    Linhagem, desempenho e orientação zootécnica devem sustentar
                    a seleção para reprodução e leilões.
                  </p>
                  <p>
                    <strong>Manejo em primeiro plano.</strong> A agenda destaca
                    vacinação e pesagem. O cronograma real deve ser definido com
                    assistência técnica, considerando o contexto sanitário da
                    propriedade.
                  </p>
                  <p>
                    <strong>Logística com responsabilidade.</strong> A
                    movimentação informa origem, destino e finalidade, com
                    lembretes de GTA e bem-estar no transporte.
                  </p>
                  <p>
                    <strong>Identidade do campo.</strong> Verde, terracota,
                    espaços amplos e linguagem direta criam uma interface
                    acolhedora. A fotografia é ilustrativa e não representa a
                    vegetação ou as raças de Tauá.
                  </p>
                </div>
                <div>
                  <h3>Equipe e orientação</h3>
                  <div className="team-list">
                    {[
                      "Francisco Gustavo",
                      "Noan Guedes",
                      "Nicollas de França",
                      "Daniel Lima",
                    ].map((n, i) => (
                      <div key={n}>
                        <span>0{i + 1}</span>
                        {n}
                      </div>
                    ))}
                  </div>
                  <p>
                    <strong>Professor orientador</strong>
                    <br />
                    Felipe Bastos
                  </p>
                  <h3>Proposta para apresentação</h3>
                  <p>
                    Sugestão a validar com a equipe: Francisco apresenta o
                    contexto e o painel; Noan, rebanho e manejo; Nicollas,
                    genética e logística; Daniel, clientes, acessibilidade e
                    implementação. Cada integrante deve relatar as decisões em
                    que realmente participou.
                  </p>
                  <h3>Arquivos e implementação</h3>
                  <p>
                    Os esquemas de leiaute estão em <code>assets/</code>. O
                    documento completo está em <code>DECISOES-LEIAUTE.md</code>.
                    Este protótipo usa React/Vite; a conversão para Next.js
                    permanece como etapa futura.
                  </p>
                </div>
              </div>
              <div className="project-disclaimer">
                <Icon name="book" /> Protótipo acadêmico. Os dados não
                representam indicadores reais nem substituem orientação
                veterinária ou zootécnica.
              </div>
            </section>
          )}
          <footer>
            <span>
              Ryeland <span className="footer-dot">·</span> Feito para quem
              cuida do campo.
            </span>
            <span>
              Projeto acadêmico · IFCE Aracati{" "}
              <span className="footer-dot">·</span> Dados demonstrativos
            </span>
          </footer>
        </main>
      </div>
      {modal === "animal" && (
        <Modal title="Cadastrar animal" onClose={() => setModal(null)}>
          <p className="modal-description">
            Uma nova história para acompanhar no seu rebanho.
          </p>
          <form onSubmit={addAnimal} className="animal-form">
            <label>
              Nome do animal
              <input
                name="name"
                required
                maxLength={60}
                autoFocus
                placeholder="Ex.: Aurora"
              />
            </label>
            <div className="form-row">
              <label>
                Espécie
                <select name="species">
                  <option>Ovino</option>
                  <option>Caprino</option>
                </select>
              </label>
              <label>
                Sexo
                <select name="sex">
                  <option>Fêmea</option>
                  <option>Macho</option>
                </select>
              </label>
            </div>
            <label>
              Raça
              <input
                name="breed"
                required
                placeholder="Ex.: Santa Inês, Boer, SRD"
              />
            </label>
            <div className="form-row">
              <label>
                Idade (meses)
                <input
                  type="number"
                  name="age"
                  min="0"
                  max="360"
                  required
                  placeholder="18"
                />
              </label>
              <label>
                Peso (kg)
                <input
                  type="number"
                  name="weight"
                  min="0.1"
                  max="250"
                  step="0.1"
                  required
                  placeholder="48,5"
                />
              </label>
            </div>
            <label>
              Fase de produção
              <select name="status">
                <option>Engorda</option>
                <option>Reprodução</option>
                <option>Seleção genética</option>
              </select>
            </label>
            <p className="form-note">
              O cadastro é salvo apenas neste navegador. Não há conexão com um
              banco de dados.
            </p>
            <div className="modal-actions">
              <button
                type="button"
                className="secondary"
                onClick={() => setModal(null)}
              >
                Cancelar
              </button>
              <button className="primary" type="submit">
                <Icon name="plus" size={16} /> Cadastrar animal
              </button>
            </div>
          </form>
        </Modal>
      )}
      {selected && (
        <Modal
          title={`Ficha de ${selected.name}`}
          onClose={() => setSelected(null)}
        >
          <div className="animal-detail-icon">
            <Icon name="sheep" size={40} />
          </div>
          <Badge color={selected.color}>{selected.status}</Badge>
          <dl className="detail-grid">
            {[
              ["Identificação", selected.id],
              ["Espécie", selected.species],
              ["Raça", selected.breed],
              ["Sexo", selected.sex],
              ["Idade", selected.age],
              ["Peso registrado", `${selected.weight} kg`],
            ].map(([label, value]) => (
              <div key={label}>
                <dt>{label}</dt>
                <dd>{value}</dd>
              </div>
            ))}
          </dl>
          <div className="detail-note">
            <Icon name="book" size={18} />
            <p>
              O histórico de pesagens, a genealogia e os registros sanitários
              são etapas previstas para a próxima versão.
            </p>
          </div>
          <button
            className="primary full-width"
            onClick={() => setSelected(null)}
          >
            Voltar ao rebanho
          </button>
        </Modal>
      )}
      {modal === "notifications" && (
        <Modal title="Notificações" onClose={() => setModal(null)}>
          <div className="notice">
            <Icon name="truck" />
            <div>
              <strong>Entrega programada para 20 de junho</strong>
              <p>Confira documentação e condições de transporte.</p>
              <button
                className="text-button"
                onClick={() => {
                  setModal(null)
                  go("Logística")
                }}
              >
                Abrir logística <Icon name="arrow" size={16} />
              </button>
            </div>
          </div>
          <div className="notice">
            <Icon name="calendar" />
            <div>
              <strong>3 atividades de manejo e visitas hoje</strong>
              <p>Acompanhe e conclua as tarefas pela agenda.</p>
              <button
                className="text-button"
                onClick={() => {
                  setModal(null)
                  go("Agenda")
                }}
              >
                Abrir agenda <Icon name="arrow" size={16} />
              </button>
            </div>
          </div>
        </Modal>
      )}
      {modal === "help" && (
        <Modal title="Bem-vindo ao Ryeland" onClose={() => setModal(null)}>
          <p className="modal-description">
            Uma iniciativa acadêmica do IFCE Campus Aracati para apoiar quem
            cria ovinos e caprinos em Tauá.
          </p>
          <div className="help-steps">
            <p>
              <Icon name="sheep" /> Cadastre animais e consulte suas fichas.
            </p>
            <p>
              <Icon name="calendar" /> Acompanhe o manejo e as visitas.
            </p>
            <p>
              <Icon name="dna" /> Organize candidatos à seleção genética.
            </p>
            <p>
              <Icon name="truck" /> Planeje transportes com responsabilidade.
            </p>
          </div>
          <button
            className="primary full-width"
            onClick={() => {
              setModal(null)
              go("Sobre o projeto")
            }}
          >
            Conhecer o projeto <Icon name="arrow" size={16} />
          </button>
        </Modal>
      )}
      {modal === "profile" && (
        <Modal title="Minha propriedade" onClose={() => setModal(null)}>
          <div className="profile-summary">
            <div className="avatar">FG</div>
            <h3>Francisco Gustavo</h3>
            <p>Administrador · Fazenda Boa Esperança</p>
            <span>
              <Icon name="pin" size={16} /> Tauá, Ceará
            </span>
          </div>
          <p className="form-note">
            Perfil demonstrativo do projeto acadêmico Ryeland. Não há
            autenticação ou dados de uma propriedade real.
          </p>
          <button
            className="secondary full-width"
            onClick={() => setModal(null)}
          >
            Voltar ao painel
          </button>
        </Modal>
      )}
      {toast && (
        <div className="toast" role="status">
          <Icon name="check" size={18} />
          {toast}
          <button aria-label="Fechar mensagem" onClick={() => setToast("")}>
            <Icon name="close" size={16} />
          </button>
        </div>
      )}
    </div>
  )
}
