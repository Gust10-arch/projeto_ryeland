# Ryeland — Next.js

Projeto acadêmico IFCE Aracati. Migração do protótipo original React/Vite para Next.js App Router.

## Executar

1. Instale Node.js 20.9+.
2. Abra esta pasta no VS Code.
3. Execute `npm install`.
4. Execute `npm run dev`.
5. Abra http://localhost:3000 e entre em **Meu rebanho**.

## Componente da atividade

`components/AnimalCard.tsx` é o componente reutilizável. Recebe `animal` e `onDetails` por props. `src/App.tsx` percorre os animais filtrados usando `.map()` e exibe um cartão para cada um. A interface mantém os dados e filtros do projeto original, e o botão abre a ficha individual.

O cadastro e a persistência continuam demonstrativos e locais ao navegador. Não há backend.
