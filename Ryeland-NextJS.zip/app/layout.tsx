import type { Metadata } from "next";
import "../src/index.css";
export const metadata: Metadata = { title: "Ryeland | Gestão do campo", description: "Projeto acadêmico de gestão de ovinos e caprinos" };
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) { return <html lang="pt-BR"><body>{children}</body></html>; }
