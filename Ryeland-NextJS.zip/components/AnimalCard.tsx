"use client";

export type AnimalCardData = {
  id: string;
  name: string;
  breed: string;
  species: string;
  sex: string;
  age: string;
  weight: number;
  status: string;
  color: string;
};

type AnimalCardProps = {
  animal: AnimalCardData;
  onDetails: () => void;
};

/** Um único componente para todos os animais, variando apenas as props. */
export default function AnimalCard({ animal, onDetails }: AnimalCardProps) {
  return (
    <article className="ryeland-animal-card">
      <div className="ryeland-animal-top">
        <span className="ryeland-animal-id">{animal.id}</span>
        <span className="ryeland-animal-status">{animal.status}</span>
      </div>
      <h3>{animal.name}</h3>
      <p className="ryeland-animal-breed">Raça: {animal.breed} · {animal.species}</p>
      <div className="ryeland-animal-metrics">
        <div><small>IDADE</small><strong>{animal.age}</strong></div>
        <div><small>PESO</small><strong>{animal.weight.toLocaleString("pt-BR")} kg</strong></div>
        <div><small>SEXO</small><strong>{animal.sex}</strong></div>
      </div>
      <button className="ryeland-animal-details" type="button" onClick={onDetails}>Ver detalhes →</button>
    </article>
  );
}
